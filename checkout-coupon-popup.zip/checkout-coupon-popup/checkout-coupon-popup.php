<?php
/*
Plugin Name: Checkout Coupon Popup
Description: Show a popup on the WooCommerce checkout page to enter and apply a coupon code.
Version: 1.0
Author: ChatGPT & Abdul Rashid
*/

if (!defined('ABSPATH')) exit;

// Inject Popup HTML and CSS
add_action('woocommerce_before_checkout_form', 'custom_coupon_popup_html');
function custom_coupon_popup_html() {
    if (is_checkout()) {
        ?>
        <style>
        #couponPopup {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0; top: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
        }
        #couponContent {
            background: #fff;
            padding: 30px;
            width: 300px;
            margin: 10% auto;
            position: relative;
            text-align: center;
        }
        #couponPopup input {
            padding: 10px;
            width: 80%;
        }
        #couponPopup button {
            margin-top: 10px;
            padding: 8px 15px;
        }
        #closePopup {
            position: absolute;
            top: 5px; right: 10px;
            cursor: pointer;
            font-size: 20px;
        }
        </style>

        <div id="couponPopup">
            <div id="couponContent">
                <span id="closePopup">&times;</span>
                <h3>Have a Coupon?</h3>
                <input type="text" id="popupCouponCode" placeholder="Enter coupon code" />
                <button id="applyCouponBtn">Apply</button>
                <p id="couponStatus" style="color:green;"></p>
            </div>
        </div>
        <?php
    }
}

// Add JS to handle popup logic
add_action('wp_footer', 'custom_coupon_popup_script');
function custom_coupon_popup_script() {
    if (is_checkout()) {
        ?>
        <script>
        document.addEventListener("DOMContentLoaded", function () {
            const popup = document.getElementById("couponPopup");
            const closeBtn = document.getElementById("closePopup");
            const applyBtn = document.getElementById("applyCouponBtn");
            const status = document.getElementById("couponStatus");

            
    if (!localStorage.getItem("coupon_popup_shown")) {
        popup.style.display = "block";
    }
    

            closeBtn.onclick = () => { popup.style.display = "none"; localStorage.setItem("coupon_popup_shown", "true"); };

            applyBtn.onclick = function () {
                const code = document.getElementById("popupCouponCode").value;

                if (!code) {
                    status.innerText = "Please enter a coupon code.";
                    return;
                }

                jQuery.post('<?php echo admin_url("admin-ajax.php"); ?>', {
                    action: 'apply_coupon_code',
                    coupon_code: code
                }, function (response) {
                    if (response.success) {
                        status.style.color = 'green';
                        status.innerText = response.data;
                        popup.style.display = "none";
                        localStorage.setItem("coupon_popup_shown", "true"); setTimeout(() => { location.reload(); }, 500);
                    } else {
                        status.style.color = 'red';
                        status.innerText = response.data;
                    }
                });
            };
        });
        </script>
        <?php
    }
}

// AJAX handler for applying coupon
add_action('wp_ajax_apply_coupon_code', 'ajax_apply_coupon_code');
add_action('wp_ajax_nopriv_apply_coupon_code', 'ajax_apply_coupon_code');

function ajax_apply_coupon_code() {
    $code = sanitize_text_field($_POST['coupon_code']);

    if (!$code) {
        wp_send_json_error("No coupon provided");
    }

    WC()->cart->add_discount($code);

    if (WC()->cart->has_discount($code)) {
        wp_send_json_success("Coupon applied successfully!");
    } else {
        wp_send_json_error("Invalid or expired coupon.");
    }
}
?>
